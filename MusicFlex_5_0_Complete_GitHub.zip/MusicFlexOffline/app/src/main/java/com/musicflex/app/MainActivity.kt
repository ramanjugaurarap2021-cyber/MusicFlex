package com.musicflex.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.net.Uri
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var controller: MediaController? = null
    private val pending = ArrayDeque<() -> Unit>()
    private val permissionCode = 42
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserCode = 1001

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = filePathCallback
                    return try {
                        val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "audio/*"
                        }
                        startActivityForResult(intent, fileChooserCode)
                        true
                    } catch (_: Exception) {
                        fileChooserCallback?.onReceiveValue(null)
                        fileChooserCallback = null
                        false
                    }
                }
            }
            addJavascriptInterface(MusicBridge(), "AndroidMusic")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/MusicFlex.html")
        connectController()
        requestAudioPermissionIfNeeded()
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            try {
                controller = future.get()
                while (pending.isNotEmpty()) pending.removeFirst().invoke()
            } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun requestAudioPermissionIfNeeded() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(permission), permissionCode)
        } else refreshSongs()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) refreshSongs()
    }

    private fun refreshSongs() {
        val json = JSONArray()
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL) else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.IS_MUSIC
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        contentResolver.query(collection, projection, selection, null, sort)?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val album = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val duration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val mediaId = c.getLong(id)
                val uri = if (Build.VERSION.SDK_INT >= 29) {
                    MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL, mediaId)
                } else {
                    ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, mediaId)
                }
                json.put(JSONObject().apply {
                    put("t", c.getString(title) ?: "Unknown title")
                    put("a", c.getString(artist)?.takeIf { it.isNotBlank() } ?: "Unknown artist")
                    put("album", c.getString(album) ?: "")
                    put("d", (c.getLong(duration).coerceAtLeast(1L)) / 1000.0)
                    put("h", ((mediaId * 37) % 360 + 360) % 360)
                    put("g", "Local")
                    put("uri", uri.toString())
                })
            }
        }
        val payload = JSONObject.quote(json.toString())
        web.post { web.evaluateJavascript("window.MusicFlexSetLocalSongs && window.MusicFlexSetLocalSongs($payload);", null) }
    }

    inner class MusicBridge {
        @JavascriptInterface
        fun playUri(uri: String, title: String, artist: String, album: String) {
            val action = {
                val item = MediaItem.Builder()
                    .setUri(uri)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).build())
                    .build()
                controller?.setMediaItem(item)
                controller?.prepare()
                controller?.play()
            }
            runOnUiThread { if (controller == null) pending.addLast(action) else action() }
        }

        @JavascriptInterface fun toggle() = runOnUiThread { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
        @JavascriptInterface fun seek(ms: Long) = runOnUiThread { controller?.seekTo(ms) }
        @JavascriptInterface fun position(): Long = controller?.currentPosition ?: 0L
        @JavascriptInterface fun isPlaying(): Boolean = controller?.isPlaying == true
        @JavascriptInterface fun setSpeed(speed: Float) = runOnUiThread { controller?.setPlaybackSpeed(speed) }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserCode) {
            val results = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            fileChooserCallback?.onReceiveValue(results)
            fileChooserCallback = null
        }
    }

    override fun onDestroy() {
        controller?.release()
        web.destroy()
        super.onDestroy()
    }
}
