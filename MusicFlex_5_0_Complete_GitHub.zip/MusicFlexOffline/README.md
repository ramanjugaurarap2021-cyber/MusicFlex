# MusicFlex 5.0 GitHub Android Project

This is the GitHub-ready Android wrapper for MusicFlex 5.0.

- Keeps the MusicFlex 5.0 HTML UI.
- Local music import through the Android file picker.
- Local music playback with Media3.
- Background/lock-screen playback for native Media3 playback.
- Internet permission enabled for the online Audius features already included in MusicFlex 5.0.
- GitHub Actions builds a debug APK.

## Build
Push this project to GitHub and run the **Build APK** workflow.
