# MusicFlex Offline

This project wraps the existing MusicFlex HTML UI in an Android app and adds local-device music playback. The visual HTML design is kept intact; Android supplies the local song library and Media3 handles playback.

## What it does
- Reads music already stored on the Android device.
- Plays local audio with Media3/ExoPlayer.
- Continues playback when the app is backgrounded or the screen is locked.
- Provides Android media notification / lock-screen controls through MediaSessionService.
- No streaming server or music API is required.
- No INTERNET permission is requested.

## Build with Android Studio
1. Install the latest Android Studio.
2. Extract this project.
3. Open the `MusicFlexOffline` folder in Android Studio.
4. Let Gradle sync and download dependencies.
5. Connect your Android phone with USB debugging enabled, or create an emulator.
6. Press **Run**.
7. Allow MusicFlex to access your music when Android asks.
8. Put MP3/M4A/other supported music files on the phone.
9. Open MusicFlex and tap a song.
10. Lock the phone. Music should continue and Android's media controls should appear.

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload the entire contents of this folder.
3. Open the **Actions** tab.
4. Run **Build MusicFlex APK**.
5. When it finishes, open the workflow run and download the `MusicFlex-debug-apk` artifact.
6. Transfer the APK to your Android phone and install it.

## Important
The HTML file is intentionally kept as the UI. The Android layer is responsible for local-media access and background playback. Media3's `MediaSessionService` is used because Android recommends it for background media playback.
